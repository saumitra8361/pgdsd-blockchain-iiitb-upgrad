package com.intellij.psi.css;

public interface CssOperation extends CssTerm {
}
