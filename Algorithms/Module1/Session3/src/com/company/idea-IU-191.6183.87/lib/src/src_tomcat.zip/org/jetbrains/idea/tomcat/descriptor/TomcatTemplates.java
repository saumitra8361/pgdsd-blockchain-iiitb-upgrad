package org.jetbrains.idea.tomcat.descriptor;

import com.intellij.javaee.oss.descriptor.JavaeeTemplatesBase;
import org.jetbrains.idea.tomcat.server.TomcatIntegration;

public class TomcatTemplates extends JavaeeTemplatesBase {

  public TomcatTemplates(TomcatIntegration tomcatIntegration) {
    super(tomcatIntegration);
  }
}
