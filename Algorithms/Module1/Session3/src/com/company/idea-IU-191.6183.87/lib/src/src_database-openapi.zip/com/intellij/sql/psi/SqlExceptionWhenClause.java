package com.intellij.sql.psi;

public interface SqlExceptionWhenClause extends SqlClause, SqlExceptionHandler {
}
