package com.intellij.sql.psi;

import com.intellij.database.model.DasRoutine;
import org.jetbrains.annotations.Nullable;

public interface SqlRoutineDefinition extends SqlDefinition, DasRoutine {
  @Nullable
  SqlStatement getBody();
}
