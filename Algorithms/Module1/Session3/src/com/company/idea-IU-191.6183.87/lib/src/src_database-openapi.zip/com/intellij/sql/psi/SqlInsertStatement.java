package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlInsertStatement extends SqlDmlStatement {
}
