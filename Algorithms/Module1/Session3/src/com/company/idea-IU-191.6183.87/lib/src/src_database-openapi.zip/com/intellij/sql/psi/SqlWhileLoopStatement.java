package com.intellij.sql.psi;

public interface SqlWhileLoopStatement extends SqlConditionalLoopStatement {
}