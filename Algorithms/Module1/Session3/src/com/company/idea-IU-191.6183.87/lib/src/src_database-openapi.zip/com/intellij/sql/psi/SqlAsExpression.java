package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * @author Gregory.Shrago
 */
public interface SqlAsExpression extends SqlExpression, SqlDefinition {
  @Override
  @Nullable
  SqlIdentifier getNameElement();

  @Nullable
  SqlExpression getExpression();

  @NotNull
  List<SqlColumnAliasDefinition> getColumnAliasList();
}
