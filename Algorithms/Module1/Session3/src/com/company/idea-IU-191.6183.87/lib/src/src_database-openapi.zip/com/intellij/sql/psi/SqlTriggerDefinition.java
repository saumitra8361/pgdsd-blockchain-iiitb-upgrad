package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlTriggerDefinition extends SqlDefinition {
}