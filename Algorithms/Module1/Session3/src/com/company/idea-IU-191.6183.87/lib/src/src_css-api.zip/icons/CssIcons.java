package icons;

import com.intellij.openapi.util.IconLoader;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class CssIcons {
  private static Icon load(String path) {
    return IconLoader.getIcon(path, CssIcons.class);
  }

  /** 16x16 */ public static final Icon Custom_property = load("/icons/css/custom_property.svg");
  /** 16x16 */ public static final Icon Property = load("/icons/css/property.svg");
  /** 16x16 */ public static final Icon Pseudo_class = load("/icons/css/pseudo-class.svg");
  /** 16x16 */ public static final Icon Pseudo_element = load("/icons/css/pseudo-element.svg");
  /** 13x13 */ public static final Icon Toolwindow = load("/icons/css/toolwindow.svg");
}
