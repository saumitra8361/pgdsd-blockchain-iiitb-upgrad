package org.jetbrains.idea.tomcat.server.tomee;

import com.intellij.javaee.oss.server.JavaeeIntegration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.tomcat.server.TomcatConfigurationBase;

public final class TomeeConfiguration extends TomcatConfigurationBase {
  public TomeeConfiguration() {
    super("TomeeConfiguration");
  }

  @NotNull
  @Override
  public JavaeeIntegration getIntegration() {
    return TomeeIntegration.getTomeeInstance();
  }

  @Override
  public String getHelpTopic() {
    return "reference.dialogs.rundebug.TomeeConfiguration";
  }
}
