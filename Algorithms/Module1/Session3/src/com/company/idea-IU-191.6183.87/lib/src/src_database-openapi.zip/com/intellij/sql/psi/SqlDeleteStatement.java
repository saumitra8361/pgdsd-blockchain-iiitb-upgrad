package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlDeleteStatement extends SqlDmlStatement {

}