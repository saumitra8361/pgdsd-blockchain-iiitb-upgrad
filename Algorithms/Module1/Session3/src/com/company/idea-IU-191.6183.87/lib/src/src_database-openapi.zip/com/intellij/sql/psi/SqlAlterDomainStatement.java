package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlAlterDomainStatement extends SqlAlterStatement {
}
