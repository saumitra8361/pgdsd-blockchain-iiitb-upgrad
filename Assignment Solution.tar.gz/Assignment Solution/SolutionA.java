import java.util.Scanner;

public class SolutionA {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int size = scanner.nextInt();
        int[] array = new int[size+1];
        int i=1;

        while(i<size+1 && scanner.hasNext()) {
            array[i] = scanner.nextInt();
            i++;
        }

        SolutionA object = new SolutionA();
        object.Search(array);
    }

    public void Search(int[] inputArr) {

        int start = 1;
        int end = inputArr.length - 1;
        boolean success = false;
        int keyValue = 0;
        while (start <= end) {
            int mid = start + ((end - start) / 2);
            if (mid == inputArr[mid]) {
                success = true;
                keyValue = mid;
                break;
            }
            if (mid < inputArr[mid]) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }
        if(success == true)
            System.out.println(keyValue);
        else
            System.out.println("NOT_FOUND");
    }
}
